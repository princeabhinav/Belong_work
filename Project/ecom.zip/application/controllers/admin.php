<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Admin_controller extends CI_Controller {

	function index(){
		echo 'welcome to admin';
	}
}
