<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class User_controller extends CI_Controller {

	function index(){
		echo 'welcome to user';
	}
}
