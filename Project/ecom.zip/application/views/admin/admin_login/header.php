<!DOCTYPE html>
	<html>
	<head>
		<title></title>

		<!-- Latest compiled and minified CSS -->
<link rel="stylesheet" href="<?php echo base_url('assets/css/bootstrap.min_new.css');?>">

<!-- jQuery library -->
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>

<!-- Latest compiled JavaScript -->

  <head>

  <link href="//maxcdn.bootstrapcdn.com/bootstrap/4.1.1/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">
<script src="//maxcdn.bootstrapcdn.com/bootstrap/4.1.1/js/bootstrap.min.js"></script>
<script src="//cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>

	<link rel="stylesheet" type="text/css" 
	<link rel="stylesheet" type="text/css" href="?<?php echo base_url('assets/scss/custom.css'); ?>">
	</head>
	<body>
		<div class="container">
			